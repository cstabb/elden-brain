# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['eldenbrain']

package_data = \
{'': ['*']}

install_requires = \
['beautifulsoup4>=4.11.1,<5.0.0',
 'click>=8.1.3,<9.0.0',
 'flatdict>=4.0.1,<5.0.0',
 'markdownify>=0.11.6,<0.12.0',
 'requests>=2.28.1,<3.0.0']

entry_points = \
{'console_scripts': ['eldenbrain = eldenbrain.cli:run']}

setup_kwargs = {
    'name': 'eldenbrain',
    'version': '0.5.0',
    'description': 'Parse a certain Elden Ring wiki into a local Obsidian Vault',
    'long_description': '\n# Elden Brain\n\nElden Brain is a tool for generating an [Obsidian Vault](https://obsidian.md/) containing pages for (almost) everything in Elden Ring. Obsidian is not only a great note-taking application, it also features a graph view that visualizes connected pages, allowing for unique insights into Elden Ring\'s elaborate interconnected world.\n\nThis tool is intended give any lore hunter a starting part in their investigations and theories, or simply for players to use as a local reference as they play the game.\n\n\n## Installation\n\nInstall using the included Wheel\n\n```bash\n  pip install .whl\n```\n\nAlternatively, download this repository and install using Poetry\n\n```bash\npoetry install\n```\n\nFollowing installing, open the included **config.ini** file and set the wiki_url variable to your favorite Elden Ring wiki.\n## Features\n\n- Automatic Obsidian Vault generation\n- CLI included, or can be used as a Python library\n- Extensive formatting options via configuration file\n\n\n## Usage/Examples\n\n### Running from the command line\nIf you wish to skip the details and create the entire Vault, type\n```bash\neldenbrain create --all\n```\nFor a more granular experience, pages can be created individually, or by category. To see the available categories, type\n```bash\neldenbrain list\n```\nTo see the names of all pages within that category (without yet creating them), type\n```bash\neldenbrain list --category "Creatures and Enemies"\n```\nTo create all pages within a category, type\n```bash\neldenbrain create --category "Creatures and Enemies"\n```\nOr create a single page if you know the name (Note: A category is not required in this case, but omitting one will place it in the Vault\'s top level)\n```bash\neldenbrain create Troll -c "Creatures and Enemies"\n```\n\nBy default, the Vault will be created in the installation directory in a folder named **cache/Elden Ring/**. This path can be changed in config.ini.\n\nNote: It is **highly** recommended that the included Obsidian settings file be used with your project. This configures the settings in Obsidian\'s graph view for the recommended Elden Brain experience. In order to use it, drop the included .obsidian folder in the local Vault folder after creation. That\'s it!\n\n### Importing as a Python library\n\nElden Brain can be imported as a Python library with the following statement:\n\n```python\nfrom eldenbrain import EldenBrain as eb\n```\n\n## Bandwidth considerations\n\nElden Brain works by scraping information from the web to generate Markdown pages. Please be thoughtful and aware of bandwidth when using this tool—keep your use of create --all to a minimum, test your config.ini changes by creating a single page, etc.\n\nBy default, downloaded assets (namely images) are *not* re-downloaded when a local page is recreated.',
    'author': 'Chris Stabb',
    'author_email': 'chris.stabb@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/cstabb/elden-brain',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
